<html>
<head>
	<title>Tu Sitio Modular</title>
	<basefont color="#FFFFFF" face="Verdana" />
</head>
<body bgcolor="#9999cc">
<?php include('includes/header.html'); ?>
<table width="100%" border="0" cellspacing="1" cellpadding="1">
	<tr>
		<td width="140" bgcolor="#5b69a6">&nbsp;</td>
		<td>
<?
	if (file_exists( $path_modulo )) include( $path_modulo );
	else die('Error al cargar el m�dulo <b>'.$modulo.'</b>. No existe el archivo <b>'.$conf[$modulo]['archivo'].'</b>');
?>
		</td>
	</tr>
</table>
<?php include('includes/footer.html'); ?>
</body>
</html>